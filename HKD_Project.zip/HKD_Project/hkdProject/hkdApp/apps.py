from django.apps import AppConfig


class HkdappConfig(AppConfig):
    name = 'hkdApp'
